export class Url {
    url: string;
}

